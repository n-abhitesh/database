--------------------------------------------------------------------------------
--write a predefined exception for cursor_already_open

DECLARE
    name employee.ename%TYPE;
    sal employee.salary%TYPE;
    CURSOR c1 IS
        SELECT ename, salary
        FROM employee
        WHERE eid BETWEEN 101 AND 105;
BEGIN
    OPEN c1;
    
    LOOP
        FETCH c1 INTO name, sal;
        EXIT WHEN c1%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(name || ' ' || sal);
    END LOOP;
    
    CLOSE c1;
EXCEPTION
    WHEN cursor_already_open THEN
        DBMS_OUTPUT.PUT_LINE('Cursor already open');
END;
/

------------------------------------------------------------------------

--write a predefined exception for invalid cursor

DECLARE
    id NUMBER(10);
    CURSOR c1 IS
        SELECT employee_id FROM employees;
BEGIN
    OPEN c1;
    CLOSE c1; -- Cursor is closed here
    
    -- Attempting to fetch from a closed cursor
    FETCH c1 INTO id;
EXCEPTION
    WHEN invalid_cursor THEN
        RAISE_APPLICATION_ERROR(-20003, 'Invalid cursor to fetch');
END;
/


-------------------------------------------
--rite a predefined exception for NO_DATA_FOUND

SET SERVEROUTPUT ON
DECLARE
    vname employ2.lastname%TYPE;
    vsal employ2.salary%TYPE;
BEGIN
    SELECT lastname, salary INTO vname, vsal FROM employ2 WHERE eid = 810;
    DBMS_OUTPUT.PUT_LINE('Last Name: ' || vname || ', Salary: ' || vsal);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No rows selected');
END;
/

---------------------------------------------------------
--my_zero_divide that is based on the predefined exception ZERO_DIVID

DECLARE
    my_zero_divide EXCEPTION;
    PRAGMA EXCEPTION_INIT(my_zero_divide, -1476); -- Using the error code for ZERO_DIVIDE
    numerator NUMBER := 10;
    denominator NUMBER := 0;
    result NUMBER;
BEGIN
    IF denominator = 0 THEN
        RAISE my_zero_divide;
    ELSE
        result := numerator / denominator;
        DBMS_OUTPUT.PUT_LINE('Result: ' || result);
    END IF;
EXCEPTION
    WHEN my_zero_divide THEN
        DBMS_OUTPUT.PUT_LINE('Custom Exception: Division by zero');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END;
/

---------------------------------------------------------------------

--write a predefined exception for case_not_found
DECLARE
    name VARCHAR2(10);
    sal NUMBER(10, 2);
    did NUMBER(5);
BEGIN
    SELECT ename, salary, dept_id
    INTO name, sal, did
    FROM employee
    WHERE eid = 106;

    CASE
        WHEN did = 204 THEN
            DBMS_OUTPUT.PUT_LINE('Meeting at 2 p.m.');
        WHEN did = 205 THEN
            DBMS_OUTPUT.PUT_LINE('Meeting at 3 p.m.');
    END CASE;

    DBMS_OUTPUT.PUT_LINE(name || ' ' || sal || ' ' || did);
END;
/

----------------------------------------------------------------------------------
--RAISE_APPLICATION_ERROR inside the EXCEPTION BLOCK


SET SERVEROUTPUT ON
DECLARE
    vname employ2.lastname%TYPE;
    vsal employ2.salary%TYPE;
BEGIN
    SELECT lastname, salary INTO vname, vsal FROM employ2 WHERE eid = 810;
    DBMS_OUTPUT.PUT_LINE('Last Name: ' || vname || ', Salary: ' || vsal);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20101, 'No rows selected');
END;
/


--------------------------------------------------------------------------------

--RAISE_APPLICATION _ERROR using cursors

DECLARE
    vname employ2.lastname%TYPE;
    vsal employ2.salary%TYPE;
    CURSOR c1 IS
        SELECT lastname, salary
        FROM employ2
        WHERE eid = 220;
BEGIN
    OPEN c1;
    FETCH c1 INTO vname, vsal;
    
    IF c1%NOTFOUND THEN
        RAISE_APPLICATION_ERROR(-20111, 'No rows selected');
    END IF;
    
    CLOSE c1;
END;
/






