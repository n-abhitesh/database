------------------------------------------------------------------------------------------

--explicit cursor

DECLARE
    vname employees.ename%TYPE;
    vjid employees.job_id%TYPE;
    CURSOR emp_det IS
        SELECT ename, job_id
        FROM employees
        WHERE emp_id BETWEEN 100 AND 175;
BEGIN
    OPEN emp_det;
    FOR i IN 1..10 LOOP
        FETCH emp_det INTO vname, vjid;
        EXIT WHEN emp_det%NOTFOUND; -- Exit loop when no more rows to fetch
        DBMS_OUTPUT.PUT_LINE(i || '. Name is: ' || vname || ', Job ID is: ' || vjid);
    END LOOP;
    CLOSE emp_det;
END;
/



----------------------------------------------------------------------------------------------

--%rowcount

DECLARE
    vname employees.ename%TYPE;
    vjid employees.job_id%TYPE;
    CURSOR emp_det IS
        SELECT ename, job_id
        FROM employees
        WHERE emp_id = 174;
BEGIN
    OPEN emp_det;
    FETCH emp_det INTO vname, vjid;
    
    DBMS_OUTPUT.PUT_LINE('Row count: ' || TO_CHAR(emp_det%ROWCOUNT));
    
    CLOSE emp_det;
END;
/



--------------------------------------------------------------------------------------------------

--%notfound

DECLARE
    vname employees.ename%TYPE;
    vjid employees.job_id%TYPE;
    CURSOR emp_det IS
        SELECT ename, job_id
        FROM employees
        WHERE emp_id = 174;
BEGIN
    OPEN emp_det;
    FETCH emp_det INTO vname, vjid;
    
    IF emp_det%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('NOT found is true');
    ELSE
        DBMS_OUTPUT.PUT_LINE('NOT found is false');
    END IF;
    
    CLOSE emp_det;
END;
/


--------------------------------------------------------------------------------------------------
--pl/sql block using records in cursor

declare
type emp_rec is record(
e_id number(15),
d_id number(15),
d_name varchar2(25));
cursor cur is
select emp_id,d.dept_id,d.dept_name from employees e, departments d where
e.dept_id=d.dept_id;
vnum number(12):=0;
begin
for emp_rec in cur
loop
fetch cur into emp_rec;
vnum:=vnum+1;
end loop;
end;

--------------------------------------------------------------------------------------------
