-------------------------------------------------------------
--cross join

CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50)
);

CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dept_id INT
);

INSERT INTO departments VALUES (1, 'HR');
INSERT INTO departments VALUES (2, 'Engineering');
INSERT INTO departments VALUES (3, 'Sales');

INSERT INTO employees VALUES (100, 'John', 'Doe', 2);
INSERT INTO employees VALUES (101, 'Jane', 'Smith', 1);
INSERT INTO employees VALUES (102, 'Alex', 'Johnson', 3);


SELECT *
FROM departments
CROSS JOIN employees;
---------------------------------------------------------------------

--equi join and inner join

CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50)
);

CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dept_id INT
);

INSERT INTO departments VALUES (1, 'HR');
INSERT INTO departments VALUES (2, 'Engineering');
INSERT INTO departments VALUES (3, 'Sales');

INSERT INTO employees VALUES (100, 'John', 'Doe', 2);
INSERT INTO employees VALUES (101, 'Jane', 'Smith', 1);
INSERT INTO employees VALUES (102, 'Alex', 'Johnson', 3);


SELECT *
FROM employees
INNER JOIN departments ON employees.dept_id = departments.dept_id;

------------------------------------------------------------------------
--non equal join


select * from employees inner join departments on employees.dept_id > departments.dept_id;



--------------------------------------------------------------------------------
--right outer join

CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50)
);

CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dept_id INT
);

INSERT INTO departments VALUES (1, 'HR');
INSERT INTO departments VALUES (2, 'Engineering');
INSERT INTO departments VALUES (3, 'Sales');

INSERT INTO employees VALUES (100, 'John', 'Doe', 2);
INSERT INTO employees VALUES (101, 'Jane', 'Smith', 1);


SELECT *
FROM employees
RIGHT JOIN departments ON employees.dept_id = departments.dept_id;

--------------------------------------------------------------------------------
--natural join

SELECT *
FROM employees
natural join departments;

------------------------------------------------------------------------------------
--self join

CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    manager_id INT
);

INSERT INTO employees VALUES (100, 'John', 'Doe', NULL);
INSERT INTO employees VALUES (101, 'Jane', 'Smith', 100);
INSERT INTO employees VALUES (102, 'Alex', 'Johnson', 100);
INSERT INTO employees VALUES (103, 'Mary', 'Brown', 101);

SELECT e1.first_name AS employee_first_name,
       e1.last_name AS employee_last_name,
       e2.first_name AS manager_first_name,
       e2.last_name AS manager_last_name
FROM employees e1
LEFT JOIN employees e2 ON e1.manager_id = e2.employee_id;



----------------------------------------------------------------------------------



