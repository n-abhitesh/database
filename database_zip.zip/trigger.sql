-----------------------------------------------------------------------
--write a pl/sql block to fire a trigger upon insertion in employee table
CREATE OR REPLACE TRIGGER tri_emp
BEFORE INSERT ON employee126
BEGIN
    IF (TO_CHAR(SYSDATE, 'dy') IN ('sat', 'sun')) OR (TO_CHAR(SYSDATE, 'HH24:MI') NOT BETWEEN '08:00' AND '12:00') THEN
        RAISE_APPLICATION_ERROR(-20500, 'You may insert into employee table only during business hours');
    END IF;
END;
/
INSERT INTO employee126 VALUES ('bavi', 7, '23-09-1999', 'M', 23000);

----------------------------------------------------------------------------------
--write a pl/sql block to fire a trigger uponinsert or update or delete in employee table

CREATE OR REPLACE TRIGGER tri_emp2
BEFORE INSERT OR UPDATE OR DELETE ON employee126
BEGIN
    IF (TO_CHAR(SYSDATE, 'dy') IN ('sat', 'sun')) OR (TO_CHAR(SYSDATE, 'HH24:MI') NOT BETWEEN '08:00' AND '12:00') THEN
        IF DELETING THEN
            RAISE_APPLICATION_ERROR(-20502, 'You may delete from the employee table only during business hours');
        ELSIF INSERTING THEN
            RAISE_APPLICATION_ERROR(-20503, 'You may insert into the employee table only during business hours');
        ELSIF UPDATING('salary') THEN
            RAISE_APPLICATION_ERROR(-20504, 'You may update salary only during business hours');
        ELSE
            RAISE_APPLICATION_ERROR(-20505, 'You may update the employee table only during business hours');
        END IF;
    END IF;
END;
/

UPDATE employee126
SET salary = 23000
WHERE eid = 2;
-----------------------------------------------------------------------------------------------
--write a pl/sql block to fire a trigger upon update of salary in employee table

CREATE OR REPLACE TRIGGER restrict_sal
BEFORE INSERT OR UPDATE OF salary ON employee126
FOR EACH ROW
BEGIN
    IF NOT (:new.fname IN ('Mansa', 'Fathima')) AND :new.salary > 15000 THEN
        RAISE_APPLICATION_ERROR(-20207, 'Employee cannot earn this amount');
    END IF;
END;
/

INSERT INTO employee126
VALUES ('bavi', 8, '23-09-1999', 'F', 23000);

---------------------------------------------------------------------------------------------------------

--.write a pl/sql block to fire a trigger upon insert or update of employee table
--And inserting the values into another table using :new and :old keyword

CREATE OR REPLACE TRIGGER restrict_emp
AFTER DELETE OR INSERT OR UPDATE ON employee126
FOR EACH ROW
BEGIN
    INSERT INTO nemp (username, change_date, old_eid, new_eid, old_fname, new_fname)
    VALUES (USER, SYSDATE, :old.eid, :new.eid, :old.fname, :new.fname);
END;
/

INSERT INTO employee126
VALUES ('bavi', 8, '23-09-1999', 'F', 20000);

-------------------------------------------------------------------------------------------------------------------


