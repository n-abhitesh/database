--------------------------------------------------------
--group functions

select count(distinct empname) as from emp;
select max(empsalary)  as maxsal from emp;
select min(empsalary)  as minsal from emp;
select avg(empsalary)  as from emp;
select sum(empsalary) as sum from emp;
--------------------------------------------------------------------