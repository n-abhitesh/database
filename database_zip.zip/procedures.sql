------------------------------------------------------------------------------------------------------------------------------
--A procedure to raise the salary of employee whose employee id is passed to the procedure by Rs
1000/-

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    first_name VARCHAR2(50),
    last_name VARCHAR2(50),
    salary NUMBER
);

INSERT INTO employees VALUES (100, 'John', 'Doe', 50000);
INSERT INTO employees VALUES (101, 'Jane', 'Smith', 60000);
-- Add more employee records as needed

CREATE OR REPLACE PROCEDURE raise_salary(e_id IN NUMBER) IS
    sal NUMBER(20);
BEGIN
    UPDATE employees SET salary = salary + 1000 WHERE employee_id = e_id;
    
    IF SQL%NOTFOUND THEN
        RAISE_APPLICATION_ERROR(-20101, 'No data found for the given employee ID');
    END IF;
    
    DBMS_OUTPUT.PUT_LINE('Salary updated');
    
    SELECT salary INTO sal FROM employees WHERE employee_id = e_id;
    DBMS_OUTPUT.PUT_LINE('Salary after updation is: ' || sal);
END;
/

BEGIN
    raise_salary(100);
END;
/
----------------------------------------------------------------------------------------------------------------------------------
--Write a procedure for formatting given number in (xxx)xxx_xxx.x form


CREATE TABLE phone_numbers (
    phone_id NUMBER PRIMARY KEY,
    phone_number NUMBER
);

INSERT INTO phone_numbers VALUES (1, 1234567890);
INSERT INTO phone_numbers VALUES (2, 9876543210);
-- Add more phone number records as needed

CREATE OR REPLACE PROCEDURE num_format (phno IN NUMBER) IS
    Vphno VARCHAR2(25);
BEGIN
    Vphno := TO_CHAR(phno);
    Vphno := '(' || SUBSTR(Vphno, 1, 3) || ')' || SUBSTR(Vphno, 4, 3) || '_' ||
             SUBSTR(Vphno, 7, 3) || '.' || SUBSTR(Vphno, 9, 1);
    
    DBMS_OUTPUT.PUT_LINE('After formatting, the number looks like:');
    DBMS_OUTPUT.PUT_LINE(Vphno);
END;
/

DECLARE
    v_phone NUMBER;
BEGIN
    -- Select a phone number from the table for demonstration
    SELECT phone_number INTO v_phone FROM phone_numbers WHERE phone_id = 1;
    
    num_format(v_phone);
END;
/

--------------------------------------------------------------------------------------------
--Procedure for raising all employees salaries by Rs.1000/-

CREATE OR REPLACE PROCEDURE raise_salary (e_id IN NUMBER) IS
    Sal NUMBER(20);
BEGIN
    UPDATE employees
    SET salary = salary + 1000
    WHERE employee_id = e_id;

    IF SQL%NOTFOUND THEN
        RAISE_APPLICATION_ERROR(-20101, 'No data found for the given employee ID');
    END IF;

    DBMS_OUTPUT.PUT_LINE('Salary updated');

    SELECT salary INTO Sal
    FROM employees
    WHERE employee_id = e_id;

    DBMS_OUTPUT.PUT_LINE('Salary after updation is: ' || Sal);
END;
/

CREATE OR REPLACE PROCEDURE raise_salaries IS
    CURSOR cur IS
        SELECT employee_id
        FROM employees
        WHERE employee_id > 100 AND employee_id < 110;
BEGIN
    FOR i IN cur LOOP
        raise_salary(i.employee_id);
    END LOOP;
END;
/


BEGIN
    raise_salaries;
END;
/

---------------------------------------------------

--procedure for armstrong

CREATE OR REPLACE PROCEDURE Armstrong (arm IN NUMBER) IS
    rem NUMBER(5);
    tot NUMBER(5) := 0;
    num NUMBER(5);
BEGIN
    num := arm;
    WHILE (num > 0) LOOP
        rem := MOD(num, 10);
        tot := tot + POWER(rem, 3);
        num := TRUNC(num / 10);
    END LOOP;

    IF (tot = arm) THEN
        DBMS_OUTPUT.PUT_LINE(arm || ' IS AN ARMSTRONG NUMBER');
    ELSE
        DBMS_OUTPUT.PUT_LINE(arm || ' IS NOT AN ARMSTRONG NUMBER');
    END IF;
END;
/

BEGIN
    Armstrong(153); -- Replace with the number you want to check
    Armstrong(370);
    Armstrong(371);
    -- Add more numbers to check
END;
/

------------------------------------------------------------------------------------------------------------------
-- procedure for out variables

CREATE OR REPLACE PROCEDURE sum_digits(num IN NUMBER, vout OUT NUMBER) IS
    rem NUMBER(5);
    sm NUMBER(5) := 0;
    num1 NUMBER(5);
BEGIN
    num1 := num;
    WHILE (num1 > 0) LOOP
        rem := MOD(num1, 10);
        sm := sm + rem;
        num1 := TRUNC(num1 / 10);
    END LOOP;
    
    vout := sm;
    DBMS_OUTPUT.PUT_LINE('Sum of digits of ' || num || ' is ' || vout);
END;
/

DECLARE
    v_result NUMBER;
BEGIN
    sum_digits(12345, v_result); -- Replace with the number you want to calculate
    DBMS_OUTPUT.PUT_LINE('Sum of digits: ' || v_result);
END;
/




