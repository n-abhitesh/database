
--example to DDL

create table employee(name varchar(20), eid number);
drop table emp1;
rename employee to emp1;
alter table employee add location varchar(20);
alter table employee modify eid varchar(20);
alter table employee drop column eid;

--exmaple to DML

create table employee(name varchar(20), eid number);
insert into employee values('abhitesh', 100);
insert into employee(name, eid) values('akhilesh', 101);
update employee set eid=102 where name='akhilesh';
delete from employee where eid=100;
select * from employee;

%, _ are wild cards