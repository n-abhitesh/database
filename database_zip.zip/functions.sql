
---------------------------------------------------------
--function which computes and returns some value

create or replace function fun_name(n in number)
return number
is 
begin

return(n*10);

end;


--using function
declare n number(10);

begin

n:=fun_name(100);
dbms_output.put_line(n);

end;


---------------------------------------------------------------

--tax of all employees (function calling another function)
CREATE OR REPLACE FUNCTION cal_tax(e_id IN NUMBER) RETURN NUMBER IS
    sal NUMBER(25);
BEGIN
    SELECT salary INTO sal FROM employees WHERE employee_id = e_id;
    RETURN (sal * 0.08); -- Assuming 8% tax rate
END;
/


CREATE OR REPLACE FUNCTION sal_tax_of_all_emp RETURN NUMBER IS
    num NUMBER(20) := 0;
    CURSOR cur IS
        SELECT employee_id FROM employees;
BEGIN
    FOR i IN cur LOOP
        DBMS_OUTPUT.PUT_LINE('Tax of employee with ID: ' || i.employee_id || ' is Rs' || cal_tax(i.employee_id));
        num := num + 1;
    END LOOP;
    RETURN num;
END;
/



DECLARE
    total_employees NUMBER;
BEGIN
    total_employees := sal_tax_of_all_emp();
    DBMS_OUTPUT.PUT_LINE(total_employees || ' employees'' salary taxes are listed.');
END;
/


------------------------------------------------------------------------------------
--perfect number

CREATE OR REPLACE FUNCTION perfct_num(pnum IN NUMBER) RETURN NUMBER IS
    sm NUMBER(8) := 0;
BEGIN
    FOR i IN 1..pnum-1 LOOP
        IF MOD(pnum, i) = 0 THEN
            sm := sm + i;
        END IF;
    END LOOP;
    
    IF sm = pnum THEN
        RETURN 1;
    ELSE
        RETURN 0;
    END IF;
END;
/


DECLARE
    bool NUMBER;
BEGIN
    bool := perfct_num(6); -- Replace with the number you want to check
    IF bool >= 1 THEN
        DBMS_OUTPUT.PUT_LINE('Given number is a perfect number');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Given number is not a perfect number');
    END IF;
END;
/



---------------------------------------------------------------------------------------

--rev a number

CREATE OR REPLACE FUNCTION rev(n IN NUMBER) RETURN NUMBER IS
    t NUMBER(10) := 0;
    r NUMBER(10) := 0;
    no NUMBER(10) := n;
BEGIN
    WHILE no > 0 LOOP
        t := MOD(no, 10);
        r := r * 10 + t;
        no := TRUNC(no / 10);
    END LOOP;
    
    RETURN r;
END;
/


DECLARE
    n NUMBER(10);
BEGIN
    n := rev(3404); -- Replace with the number you want to reverse
    DBMS_OUTPUT.PUT_LINE(n);
END;
/




