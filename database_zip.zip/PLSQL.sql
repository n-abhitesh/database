
-------------------------------------------------------------------------
--when clasue  demonstarte

CREATE TABLE sgrade (
    grade VARCHAR(1) PRIMARY KEY,
    low NUMBER,
    high NUMBER
);

INSERT INTO sgrade VALUES ('a', 85, 100);
INSERT INTO sgrade VALUES ('b', 70, 84);
INSERT INTO sgrade VALUES ('c', 50, 69);

DECLARE
    v NUMBER := 88;
    v1 VARCHAR(1);
    v2 VARCHAR(10);
BEGIN
    SELECT grade INTO v1
    FROM sgrade
    WHERE (low <= v AND high >= v);
    
    dbms_output.put_line('Grade: ' || v1);
    
    v2 := CASE v1
        WHEN 'a' THEN 'Excellent'
        WHEN 'b' THEN 'Good'
        WHEN 'c' THEN 'Average'
        ELSE 'Unknown'
    END;
    
    DBMS_OuTPUT.PUT_LINE('Description: ' || v2);
END;---------------------------------------------------------------------------------------------------

-- loop


create table jyo (id number, name varchar(3));
declare 
i number:=0;

begin

loop

insert into jyo values(101, 'abh');
i:=i+1;
exit when i=2;

end loop;

end;

select * from jyo
---------------------------------------------------------------------------------------------------------------------
-- for loop

create table jyp (id number, name varchar(3));


declare 
I number:=0;
begin 

for I in 0..4
loop 
insert into jyp
values(101, 'jyp');
end loop;

end;

select * from jyp;
---------------------------------------------------------------------------------------------------------------
-- cursor

CREATE TABLE emp (
    empno NUMBER PRIMARY KEY,
    ename VARCHAR2(50),
    deptno NUMBER
);

INSERT INTO emp VALUES (101, 'John Doe', 10);
INSERT INTO emp VALUES (102, 'Jane Smith', 20);
INSERT INTO emp VALUES (103, 'Alex Johnson', 10);
-- Add more employee records as needed

DECLARE
    vDeptno emp.deptno%TYPE := 30;
    vEname emp.ename%TYPE;
    vEmpno emp.empno%TYPE;
    i NUMBER := 0;
    j NUMBER := 1;
    CURSOR cursor_emp IS
        SELECT ename, empno
        FROM emp
        WHERE deptno = vDeptno;
BEGIN
    OPEN cursor_emp;
    
    SELECT COUNT(empno) INTO j
    FROM emp
    WHERE deptno = vDeptno;
    
    LOOP
        FETCH cursor_emp INTO vEname, vEmpno;
        DBMS_OUTPUT.PUT_LINE(vEname || ' and ' || vEmpno);
        i := i + 1;
        EXIT WHEN i = j;
    END LOOP;
    
    CLOSE cursor_emp;
END;

