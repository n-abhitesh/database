--------------------------------------------------------------------
--case manipultion function
Select lower(major) from STUDENT;
select upper(name1) from STUDENT;
select lower(major)||initcap(name1) as Details from student ;
select name1,student_number,class1 from student
where upper(major)='CS';

-------------------------------------------------------------------
--character manipulation function

select concat(student_number,name1) from student;
select substr(name1,1,4) from student;
select substr(name1,4) from student;
select length(student_number) from student;
select length('Hello WORLd') from dual;
select instr(name1,'a') from student;
select lpad(section_identifier,10,'-') from section1;
select rpad(section_identifier,10,'*') from section1;
select trim('G'from instuctor) from section1;
select replace('Mississipie','s','x') from dual;
SELECT CONCAT(name1,concat('-',student_number)) from student;

-----------------------------------------------------------------
--number functions

SELECT ROUND(45.89112) FROM DUAL;
SELECT TRUNC(45.89112) FROM DUAL;
SELECT MOD(1002,55) FROM DUAL;

---------------------------------------------------------------
--date functions

SELECT SYSDATE FROM DUAL;
SELECT MONTHS_BETWEEN(SYSDATE,'12-NOV-2018') FROM DUAL;
SELECT ADD_MONTHS(SYSDATE,'4') FROM DUAL;
SELECT NEXT_DAY('21-FEB-18','MONDAY') FROM DUAL;
--next monday
SELECT LAST_DAY('21-FEB-18') FROM DUAL;
--last day of month
SELECT ROUND(TO_DATE('19-DEC-2017'),'MONTH') FROM DUAL;
SELECT ROUND(TO_DATE('19-MAR-2017'),'YEAR') FROM DUAL;
-----------------------------------------------------------------
--conversion functions

select to_char(SYSDATE,'yyyy')from dual;
select to_char(SYSDATE,'year')from dual;

---------------------------------------------------------------
--general functions

select nvl(sid,129) from cbit;
select nvl2(sid,name,'ting') from cbit;
select NULLIF('jon','jon') from dual;
select coalesce(null,null,'hh') from dual;


