

-----------------------------------------------------------------------------
select deptno,avg(sal) from scott.emp
group by deptno;

select min(sal),max(sal),deptno from scott.emp
group by deptno;

select deptno from scott.emp
where deptno <= 20
group by deptno
order by deptno;
--------------------------------------------------------------------------