----------------------------------------------------------------------------
--primary key constraint

CREATE TABLE student_d (
    sid NUMBER,
    sname VARCHAR(10),
    sdept VARCHAR(6),
    semail VARCHAR(20)
);

INSERT INTO student_d VALUES (100, 'abhi', 'cse', 'n.abhitesh');
INSERT INTO student_d VALUES (101, 'akhil', 'cse', 'n.akhilesh');
INSERT INTO student_d VALUES (102, 'sonu', 'cse', 'sonu.kokapet');


ALTER TABLE student_d
ADD CONSTRAINT pk_sid PRIMARY KEY (sid);

INSERT INTO student_d VALUES (100, 'ghut', 'ihj', 'jhyuik@gmail.com');




------------------------------------------------------------------------------
--unique constraint

CREATE TABLE student_d (
    sid NUMBER,
    sname VARCHAR(10),
    sdept VARCHAR(6),
    semail VARCHAR(20)
);


ALTER TABLE student_d
ADD CONSTRAINT uc_semail UNIQUE (semail);

INSERT INTO student_d VALUES (100, 'abhi', 'cse', 'n.abhitesh');
INSERT INTO student_d VALUES (101, 'akhil', 'cse', 'n.akhilesh');
INSERT INTO student_d VALUES (102, 'sonu', 'cse', 'sonu.kokapet');


INSERT INTO student_d VALUES (103, 'new_student', 'new_dept', 'n.abhitesh');


------------------------------------------------------------------------------------------
--forigen key constraint


CREATE TABLE departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50)
);

CREATE TABLE students (
    student_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dept_id INT,
    CONSTRAINT fk_dept FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);


INSERT INTO departments VALUES (1, 'Computer Science');
INSERT INTO departments VALUES (2, 'Electrical Engineering');

INSERT INTO students VALUES (100, 'John', 'Doe', 1);
INSERT INTO students VALUES (101, 'Jane', 'Smith', 2);
INSERT INTO students VALUES (102, 'Alex', 'Johnson', 1);


INSERT INTO students VALUES (103, 'New', 'Student', 3);

-----------------------------------------------------------------------------------------------
--not null constraint

CREATE TABLE student_d (
    sid NUMBER PRIMARY KEY,
    sname VARCHAR(10) NOT NULL,
    sdept VARCHAR(6),
    semail VARCHAR(20)
);


INSERT INTO student_d VALUES (100, NULL, 'cse', 'n.abhitesh');


---------------------------------------------------------------------------------------------------
--check constraint

CREATE TABLE student_d (
    sid NUMBER PRIMARY KEY,
    sname VARCHAR(10),
    sdept VARCHAR(6) CHECK (sdept IN ('cse', 'ece', 'mech')),
    semail VARCHAR(20)
);


INSERT INTO student_d VALUES (100, 'abhi', 'chem', 'n.abhitesh');

-----------------------------------------------------------------------------------------------------
--drop constraint

alter table student_d
drop constraint semail_constraint;

---------------------------------------------------------------------------------------------------
--to check user constraints

select constraint_name,constraint_type from user_constraints;
